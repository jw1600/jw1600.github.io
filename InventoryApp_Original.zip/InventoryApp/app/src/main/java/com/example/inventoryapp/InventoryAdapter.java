package com.example.inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    Context context;
    ArrayList<InventoryItem> items;
    DatabaseHelper db;

    public InventoryAdapter(Context context, ArrayList<InventoryItem> items, DatabaseHelper db) {
        this.context = context;
        this.items = items;
        this.db = db;
    }

    @NonNull
    @Override
    public InventoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryAdapter.ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.nameText.setText(item.name);
        holder.quantityText.setText("Qty: " + item.quantity);

        holder.deleteButton.setOnClickListener(v -> {
            if (db.deleteItem(item.id)) {
                Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
                items.remove(position);
                notifyItemRemoved(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, quantityText;
        Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemNameText);
            quantityText = itemView.findViewById(R.id.itemQuantityText);
            deleteButton = itemView.findViewById(R.id.deleteItemButton);
        }
    }
}
