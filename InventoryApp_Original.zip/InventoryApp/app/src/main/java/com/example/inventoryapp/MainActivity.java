package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Button addItemButton, smsButton;
    DatabaseHelper db;
    InventoryAdapter adapter;
    ArrayList<InventoryItem> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        smsButton = findViewById(R.id.smsButton);
        db = new DatabaseHelper(this);

        itemList = new ArrayList<>();
        adapter = new InventoryAdapter(this, itemList, db);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        loadItems();

        addItemButton.setOnClickListener(v -> startActivity(new Intent(this, AddItemActivity.class)));

        smsButton.setOnClickListener(v -> startActivity(new Intent(this, SMSActivity.class)));
    }

    private void loadItems() {
        itemList.clear();
        Cursor cursor = db.getAllItems();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));
            itemList.add(new InventoryItem(id, name, quantity));
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems(); // reload after adding new items
    }
}
