package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText usernameEditText, passwordEditText;
    Button loginButton, createButton;
    TextView titleText;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);

        titleText = findViewById(R.id.titleText);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createButton = findViewById(R.id.createButton);


        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Utils.showToast(this, "Please enter username and password");
                return;
            }

            if (db.checkUserExists(username, password)) {
                Utils.showToast(this, "Login successful");
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Utils.showToast(this, "Invalid username or password");
            }
        });


        createButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Utils.showToast(this, "Please enter username and password");
                return;
            }

            if (db.checkUsernameExists(username)) {
                Utils.showToast(this, "Account already exists");
            } else {
                boolean inserted = db.addUser(username, password);
                if (inserted) {
                    Utils.showToast(this, "Account created successfully. Please login.");
                } else {
                    Utils.showToast(this, "Account creation failed. Please try again.");
                }
            }
        });
    }
}
