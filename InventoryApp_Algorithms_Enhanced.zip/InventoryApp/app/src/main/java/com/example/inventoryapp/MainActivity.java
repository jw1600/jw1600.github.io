package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Button addItemButton, smsButton;
    Button btnSortNameAsc, btnSortNameDesc, btnSortQuantity;
    EditText searchBar;

    DatabaseHelper db;
    InventoryAdapter adapter;
    ArrayList<InventoryItem> itemList = new ArrayList<>();
    HashMap<Integer, InventoryItem> itemHashMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        addItemButton = findViewById(R.id.addItemButton);
        smsButton = findViewById(R.id.smsButton);
        searchBar = findViewById(R.id.searchBar);
        btnSortNameAsc = findViewById(R.id.btnSortNameAsc);
        btnSortNameDesc = findViewById(R.id.btnSortNameDesc);
        btnSortQuantity = findViewById(R.id.btnSortQuantity);

        db = new DatabaseHelper(this);
        adapter = new InventoryAdapter(this, itemList, db);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        setupSearchAndSort();
        loadItems();

        addItemButton.setOnClickListener(v -> startActivity(new Intent(this, AddItemActivity.class)));
        smsButton.setOnClickListener(v -> startActivity(new Intent(this, SMSActivity.class)));
    }

    private void setupSearchAndSort() {
        searchBar.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterItems(s.toString());
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void afterTextChanged(Editable s) {}
        });

        btnSortNameAsc.setOnClickListener(v -> sortItems("name_asc"));
        btnSortNameDesc.setOnClickListener(v -> sortItems("name_desc"));
        btnSortQuantity.setOnClickListener(v -> sortItems("quantity"));
    }

    private void loadItems() {
        itemList.clear();
        itemHashMap.clear();

        Cursor cursor = null;
        try {
            cursor = db.getAllItems();
            int count = 0;

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                    int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("quantity"));

                    InventoryItem item = new InventoryItem(id, name, quantity);
                    itemList.add(item);
                    itemHashMap.put(id, item);
                    count++;
                } while (cursor.moveToNext());
            }

            adapter.updateItems(itemList);
            Utils.showToast(this, "Loaded " + count + " items");

        } catch (Exception e) {
            e.printStackTrace();
            Utils.showToast(this, "Error loading items");
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void filterItems(String text) {
        ArrayList<InventoryItem> filtered = new ArrayList<>();
        String query = text.toLowerCase().trim();
        for (InventoryItem item : itemList) {
            if (item.name.toLowerCase().contains(query)) {
                filtered.add(item);
            }
        }
        adapter.updateItems(filtered);
    }

    private void sortItems(String type) {
        if (type.equals("name_asc")) {
            itemList.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
        } else if (type.equals("name_desc")) {
            itemList.sort((a, b) -> b.name.compareToIgnoreCase(a.name));
        } else {
            itemList.sort((a, b) -> Integer.compare(a.quantity, b.quantity));
        }
        adapter.updateItems(itemList);
        Utils.showToast(this, "Sorted successfully");
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }
}