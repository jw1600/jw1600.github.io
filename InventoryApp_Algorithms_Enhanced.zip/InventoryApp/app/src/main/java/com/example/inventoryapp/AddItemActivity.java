package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {

    EditText nameEditText, quantityEditText;
    Button saveButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        db = new DatabaseHelper(this);

        nameEditText = findViewById(R.id.nameEditText);
        quantityEditText = findViewById(R.id.quantityEditText);
        saveButton = findViewById(R.id.saveItemButton);

        saveButton.setOnClickListener(v -> {
            String name = nameEditText.getText().toString().trim();
            String qtyStr = quantityEditText.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Utils.showToast(this, "Please enter name and quantity");
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(qtyStr);
                if (quantity < 0) {
                    Utils.showToast(this, "Quantity cannot be negative");
                    return;
                }
            } catch (NumberFormatException e) {
                Utils.showToast(this, "Please enter a valid number");
                return;
            }

            if (db.addItem(name, quantity)) {
                Utils.showToast(this, "Item added successfully");
                finish();
            } else {
                Utils.showToast(this, "Failed to add item");
            }
        });
    }
}
